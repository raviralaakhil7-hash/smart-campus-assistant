from flask import Flask, render_template, request, session
from chatbot_ai import get_response

app = Flask(__name__)
app.secret_key = "supersecretkey"  # Needed for session

@app.route("/", methods=["GET", "POST"])
def home():
    if "chat" not in session:
        session["chat"] = []  # store chat history

    if request.method == "POST":
        user_text = request.form["msg"]
        bot_reply = get_response(user_text)

        # save both user and bot messages
        session["chat"].append({"sender": "user", "text": user_text})
        session["chat"].append({"sender": "bot", "text": bot_reply})

    return render_template("index.html", chat=session["chat"])

if __name__ == "__main__":
    app.run(debug=True)