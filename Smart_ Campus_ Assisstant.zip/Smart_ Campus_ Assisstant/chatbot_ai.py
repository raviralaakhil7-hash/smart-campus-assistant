import database

def get_response(user_text):
    user_text = user_text.lower()

    if "library" in user_text:
        return "📚 The library is open from 9 AM to 8 PM."
    elif "dining" in user_text or "food" in user_text:
        return "🍴 Today's menu: Veg Biryani, Chicken Curry, and Salad."
    elif "schedule" in user_text:
        return database.get_class_schedule("CSE")  # Example DB call
    elif "facilities" in user_text:
        return "🏫 We have labs, sports ground, and hostel facilities."
    else:
        return "❓ Sorry, I don’t know that yet. Please ask admin."