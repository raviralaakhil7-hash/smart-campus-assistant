import sqlite3

def get_class_schedule(department):
    conn = sqlite3.connect("campus.db")   # Connect to DB file
    cur = conn.cursor()
    cur.execute("SELECT schedule FROM schedules WHERE department=?", (department,))
    result = cur.fetchone()
    conn.close()
    return result[0] if result else "No schedule found."
