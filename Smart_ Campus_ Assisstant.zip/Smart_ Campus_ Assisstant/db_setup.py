import sqlite3

conn = sqlite3.connect("campus.db")
cur = conn.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS schedules (department TEXT, schedule TEXT)")
cur.execute("DELETE FROM schedules")  # clear old data
cur.execute("INSERT INTO schedules VALUES ('CSE', 'Mon-Fri: 9AM-4PM')")
cur.execute("INSERT INTO schedules VALUES ('ECE', 'Mon-Fri: 10AM-5PM')")
conn.commit()
conn.close()

print("✅ Database created with schedules")
